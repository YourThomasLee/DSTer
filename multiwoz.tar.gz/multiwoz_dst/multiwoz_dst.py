import json
from typing import Dict, List, Set

import datasets
import sys
from sklearn.model_selection import train_test_split


DATA_PATH = "https://ytlin.s3.ap-northeast-1.amazonaws.com/data/huggingface_datasets/multiwoz/gcn_data_2.2.json"
DELEX_DATA_PATH = "https://ytlin.s3-ap-northeast-1.amazonaws.com/data/delex.json"
SCHEMA_22_PATH = "https://raw.githubusercontent.com/budzianowski/multiwoz/master/data/MultiWOZ_2.2/schema.json"


def is_binary_slot(domain: str, slot_name: str) -> bool:
    if domain == "Hotel" and slot_name == "parking":
        return True
    if domain == "Hotel" and slot_name == "internet":
        return True
    return False


def is_categorical_slot(schema: List[Dict], domain: str, slot_name: str) -> bool:
    # Special cases
    if slot_name == "none":
        return False

    domain_slot_name = f"{domain.lower()}-{''.join(slot_name.lower().split())}"
    for service in schema:
        for slot in service["slots"]:
            if slot["name"] == domain_slot_name:
                return slot["is_categorical"]
    return False


def get_binary_slot_text(user_dialogue_acts: List[List[str]]) -> str:
    return " ".join(
        f"[{domain} {slot_name} {value}]"
        for domain, act_type, slot_name, value in sorted(user_dialogue_acts)
        if act_type == "Inform" and is_binary_slot(domain, slot_name)
    )


def get_categorical_slot_text(
    schmea: List[Dict], user_dialogue_acts: List[List[str]]
) -> str:
    return " ".join(
        f"[{domain} {slot_name} {value}]"
        for domain, act_type, slot_name, value in sorted(user_dialogue_acts)
        if act_type == "Inform" and is_categorical_slot(schmea, domain, slot_name)
    )


def generate_natural_user_prompt(user_actions) -> str:
    user_actions.sort()

    first_attraction_inform = True
    first_hotel_inform = True
    first_restaurant_inform = True
    first_taxi_inform = True
    first_train_inform = True
    for domain, act, slot, value in user_actions:
        if domain == "Attraction":
            if act == "Inform":
                if first_attraction_inform:
                    yield "You are also looking for places to go in town."
                    first_attraction_inform = False
                if slot == "area":
                    yield f"The attraction should be in the {value}."
                elif slot == "entrancefee":
                    if value == "dontcare":
                        yield f"You do not care about the entrance fee."
                    else:
                        yield f"The entrance fee should be {value}."
                elif slot == "name":
                    yield f"You are looking for a particular attraction. Its name is called {value}."
                elif slot == "none":
                    continue
                elif slot == "type":
                    yield f"The attraction should be in the type of {value}."
                else:
                    raise ValueError(f"Unknown slot: {domain, act, slot, value}")
            elif act == "Request":
                if slot == "entrancefee":
                    yield f"Make sure you get the attraction entrance fee."
                elif slot == "parking":
                    yield f"Make sure you get the attraction parking information."
                else:
                    yield f"Make sure you get the attraction {slot}."
        elif domain == "Hospital":
            if act == "Inform":
                yield f"You are looking for {value} in Addenbrookes Hospital."
            elif act == "Request":
                yield f"Make sure you get the hospital {value}."
            else:
                raise ValueError(f"Unknown slot: {domain, act, slot, value}")
        elif domain == "Hotel":
            if act == "Inform":
                if first_hotel_inform:
                    yield "You are planning your trip in Cambridge. You are looking for a place to stay."
                    first_hotel_inform = False
                if slot == "area":
                    yield f"The hotel should be in the {value}."
                elif slot == "book day":
                    if value == "dontcare":
                        yield f"You can to book it on any day."
                    else:
                        yield f"You want to book it on {value}."
                elif slot == "book people":
                    yield f"You want to book it for {value} people."
                elif slot == "book stay":
                    if value == "dontcare":
                        yield f"You can to book it for any nights."
                    else:
                        yield f"You want to book it for {value} nights."
                elif slot == "choice":
                    pass
                elif slot == "internet":
                    if value == "dontcare":
                        yield f"You do not care about the internet."
                    elif value == "yes":
                        yield f"The hotel should have free wifi."
                    elif value == "no":
                        yield f"The hotel can have paid wifi."
                elif slot == "name":
                    yield f"You are looking for a particular hotel. Its name is called {value}."
                elif slot == "parking":
                    if value == "dontcare":
                        yield f"You do not care about the parking fee."
                    elif value == "yes" or value == "free":
                        yield f"The hotel should have free parking."
                    elif value == "no":
                        yield f"The hotel can have paid parking."
                elif slot == "pricerange":
                    if value == "dontcare":
                        yield "You don't care about the hotel price range."
                    else:
                        yield f"The hotel should be in the {value} price range."
                elif slot == "stars":
                    if value == "dontcare":
                        yield "You don't care about the hotel stars."
                    else:
                        yield f"The hotel should be in the {value} stars."
                elif slot == "type":
                    if value == "dontcare":
                        yield "You don't care about the hotel type."
                    else:
                        yield f"The hotel should be in the type of {value}."
                elif slot == "none":
                    continue
                else:
                    raise ValueError(f"Unknown slot: {domain, act, slot, value}")
            elif act == "Request":
                if slot == "internet":
                    yield f"Make sure you get the hotel internet information."
                elif slot == "parking":
                    yield f"Make sure you get the hotel parking information."
                elif slot == "pricerange":
                    yield f"Make sure you get the hotel price range."
                elif slot == "ref":
                    yield f"Make sure you get the hotel booking reference number."
                else:
                    yield f"Make sure you get the hotel {slot}."
        elif domain == "Police":
            if act == "Request":
                yield f"Make sure you get the police station {slot}."
        elif domain == "Restaurant":
            if act == "Inform":
                if first_restaurant_inform:
                    yield "You are traveling to Cambridge and looking forward to try local restaurants."
                    first_restaurant_inform = False
                if slot == "area":
                    yield f"The restaurant should be in the {value}."
                elif slot == "book day":
                    if value == "dontcare":
                        yield f"You can to book it on any day."
                    else:
                        yield f"You want to book it on {value}."
                elif slot == "book people":
                    yield f"You want to book it for {value} people."
                elif slot == "book time":
                    yield f"You want to book it at {value}."
                elif slot == "food":
                    yield f"The restaurant should serve {value} food."
                elif slot == "none":
                    pass
                elif slot == "name":
                    yield f"You are looking for a particular restaurant. Its name is called {value}."
                elif slot == "pricerange":
                    if value == "dontcare":
                        yield "You don't care about the restaurant price range."
                    else:
                        yield f"The restaurant should be in the {value} price range."
                else:
                    raise ValueError(f"Unknown slot: {domain, act, slot, value}")
            elif act == "Request":
                if slot == "pricerange":
                    yield f"Make sure you get the restaurant price range."
                elif slot == "ref":
                    yield f"Make sure you get the restaurant booking reference number."
                else:
                    yield f"Make sure you get the restaurant {slot}."
        elif domain == "Taxi":
            if act == "Inform":
                if first_taxi_inform:
                    yield "You want to book a taxi."
                    first_taxi_inform = False
                if slot == "arriveby":
                    yield f"The taxi should arrive by {value}."
                elif slot == "book people":
                    yield f"You want to book it for {value} people."
                elif slot == "departure":
                    yield f"The taxi should depart from {value}."
                elif slot == "destination":
                    yield f"The taxi should go to {value}."
                elif slot == "leaveat":
                    yield f"The taxi should leave at {value}."
                elif slot == "none":
                    pass
                else:
                    raise ValueError(f"Unknown slot: {domain, act, slot, value}")
            elif act == "Request":
                yield f"Make sure you get the taxi {slot}."
        elif domain == "Train":
            if act == "Inform":
                if first_train_inform:
                    yield "You want to book a train."
                    first_train_inform = False
                if slot == "arriveby":
                    yield f"The train should arrive by {value}."
                elif slot == "book people":
                    yield f"You want to book it for {value} people."
                elif slot == "day":
                    yield f"You want to book it on {value}."
                elif slot == "departure":
                    yield f"The train should depart from {value}."
                elif slot == "destination":
                    yield f"The train should go to {value}."
                elif slot == "leaveat":
                    yield f"The train should leave at {value}."
                elif slot == "none" or slot == "price":
                    pass
                else:
                    raise ValueError(f"Unknown slot: {domain, act, slot, value}")
            elif act == "Request":
                if slot == "arriveby":
                    yield f"Make sure you get the train arrive time."
                elif slot == "duration":
                    yield f"Make sure you get the train duration."
                elif slot == "leaveat":
                    yield f"Make sure you get the train departure time."
                elif slot == "trainid":
                    yield f"Make sure you get the train id."
                elif slot == "ref":
                    yield f"Make sure you get the train booking reference number."
                else:
                    yield f"Make sure you get the train {slot}."
        elif domain == "general":
            if act == "bye":
                return "Bye"
            elif act == "greet":
                return "Greetings"
            elif act == "thank":
                return "Thank you"
        else:
            raise ValueError(f"Unknown domain: {domain}")
    return ""


class MultiWozDST(datasets.GeneratorBasedBuilder):
    VERSION = datasets.Version("1.2.0")
    DEFAULT_CONFIG_NAME = "default"
    BUILDER_CONFIGS = [datasets.BuilderConfig(name="default")]

    num_history_turns = 3

    def _info(self):
        features = datasets.Features(
            {
                "dialogue_id": datasets.Value("string"),
                "turn": datasets.Value("int32"),
                "goal_description": datasets.Value("string"),
                "user_utterance": datasets.Value("string"),
                "user_delex_utterance": datasets.Value("string"),
                "system_delex_utterance": datasets.Value("string"),
                "natural_user_delex_utterance": datasets.Value("string"),
                "binary_slot_text": datasets.Value("string"),
                "binary_slot_text+natural_user_delex_utterance": datasets.Value(
                    "string"
                ),
                "categorical_slot_text": datasets.Value("string"),
                "categorical_slot_text+natural_user_delex_utterance": datasets.Value(
                    "string"
                ),
                "dialogue_history": datasets.Sequence(datasets.Value("string")),
                "dialogue_states": datasets.Sequence(
                    datasets.Sequence(datasets.Value("string"))
                ),
                "partial_states": datasets.Sequence(
                    datasets.Sequence(datasets.Value("string"))
                ),
                "user_dialogue_acts": datasets.Sequence(
                    datasets.Sequence(datasets.Value("string"))
                ),
                "natural_user_dialogue_acts": datasets.Value("string"),
                "context": datasets.Value("string"),
                "natural_user_dialogue_acts+context": datasets.Value("string"),
            }
        )
        return datasets.DatasetInfo(features=features)

    def _split_generators(self, dl_manager: datasets.DownloadManager):
        data_path = sys.path[0] + "/gcn_data_2.2.json" #dl_manager.download_and_extract(DATA_PATH)
        delex_path = sys.path[0] + "/delex.json" #dl_manager.download_and_extract(DELEX_DATA_PATH)
        schema_path = sys.path[0] + "/schema.json" #dl_manager.download_and_extract(SCHEMA_22_PATH)
        print("data path:", data_path)
        with open(data_path) as f:
            data = json.load(f)
        with open(delex_path) as f:
            delex_data = json.load(f)
        with open(schema_path) as f:
            self.schema = json.load(f)

        dialogue_ids = [turn["dialogue_id"] for turn in data]
        train_indices, test_indices = train_test_split(
            dialogue_ids, test_size=0.1, random_state=42
        )
        train_indices = set(train_indices)
        test_indices = set(test_indices)

        return [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN,
                gen_kwargs={
                    "data": data,
                    "delex_data": delex_data,
                    "dialogue_ids": train_indices,
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.VALIDATION,
                gen_kwargs={
                    "data": data,
                    "delex_data": delex_data,
                    "dialogue_ids": test_indices,
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.TEST,
                gen_kwargs={
                    "data": data,
                    "delex_data": delex_data,
                    "dialogue_ids": test_indices,
                },
            ),
        ]

    def _generate_examples(self, data, delex_data, dialogue_ids: Set[str]):
        id_ = -1
        for turn in data:
            if turn["dialogue_id"] not in dialogue_ids:
                continue
            turn["user_delex_utterance"] = delex_data[turn["dialogue_id"]]["log"][
                turn["turn"] * 2
            ]["text"]
            turn["system_delex_utterance"] = delex_data[turn["dialogue_id"]]["log"][
                turn["turn"] * 2 + 1
            ]["text"]
            turn["natural_user_delex_utterance"] = (
                delex_data[turn["dialogue_id"]]["log"][turn["turn"] * 2]["text"]
                .replace("value_", "")
                .replace("pricerange", "price range")
                .replace("bookday", "book day")
                .replace("bookpeople", "book people")
                .replace("bookstay", "book stay")
                .replace("arriveby", "arrive by")
                .replace("leaveat", "leave at")
                .replace("booktime", "book time")
            )

            turn["context"] = (
                f"{'<|endoftext|>'.join(turn['dialogue_history'][-self.num_history_turns:])} "
                f"<|endoftext|>"
            )
            turn["natural_user_dialogue_acts"] = " ".join(
                generate_natural_user_prompt(turn["user_dialogue_acts"])
            )
            turn["natural_user_dialogue_acts+context"] = (
                f"actions: {turn['natural_user_dialogue_acts']} "
                f"context: {turn['context']}"
            )
            turn["binary_slot_text"] = get_binary_slot_text(turn["user_dialogue_acts"])
            turn[
                "binary_slot_text+natural_user_delex_utterance"
            ] = f"{turn['binary_slot_text']} {turn['natural_user_delex_utterance']}"
            turn["categorical_slot_text"] = get_categorical_slot_text(
                self.schema, turn["user_dialogue_acts"]
            )
            turn[
                "categorical_slot_text+natural_user_delex_utterance"
            ] = f"{turn['categorical_slot_text']} {turn['natural_user_delex_utterance']}"
            id_ += 1
            yield id_, turn
